# Smart Lost & Found Management Portal

> **Full Stack Web Development Project**  
> An intelligent, responsive web portal for reporting, matching, claiming, and recovering lost and found items. Powered by Supabase (Auth, PostgreSQL with RLS, Storage) and an intelligent client-side similarity scoring engine.

---

## 🚀 Key Features

1. **Item Explorer & Advanced Filtering**:
   - Filter by status (`Open`, `Pending Claim`, `Resolved`), category, and post type (`Lost` vs `Found`).
   - Instant text search across item title, description, and location.

2. **Smart AI Similarity Engine (`js/matching.js`)**:
   - Automatic cross-matching between `Lost` and `Found` posts.
   - Multi-factor scoring model combining category matching, tokenized text Jaccard similarity, Levenshtein fuzzy metrics, location keyword overlap, and date proximity.
   - Match confidence percentage badge and dedicated **"Smart Matches"** side-by-side comparison screen.

3. **Secure Claims & Verification Portal**:
   - Anyone finding their lost item can submit a claim with proof of ownership.
   - Finders receive real-time notifications with full claimant contact info.
   - Finders can **Approve & Release** or **Reject** claims, automatically transitioning item status from `open` to `pending_claim` to `resolved`.

4. **Notification System**:
   - Interactive dropdown with unread badge counter.
   - Real-time alerts on new claims and claim status approvals/rejections.

5. **Dedicated Authentication & Login Portal (`login.html`)**:
   - Clean, responsive page with **Sign In** and **Create Account** forms.
   - Connected to Supabase Auth (`supabase.auth.signInWithPassword` & `signUp`).
   - Integrated **1-Click Quick Demo Login** buttons for Alice Chen (Finder), Bob Martinez (Owner), and Clara Vance (Student).
   - Password visibility toggles, form validation, and session management with navbar Sign In / Sign Out controls.

6. **Dual-Mode Operation**:
   - **Instant Demo Mode**: Preloaded with realistic paired sample items (MacBook Air, Fossil wallet, car keys, AirPods, student ID) in browser local storage. Allows instant testing and presentation without external setup.
   - **Live Supabase Mode**: Connects seamlessly to a real Supabase backend with PostgreSQL, Row Level Security, email auth, and cloud image storage.

---

## 🛠️ Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend** | HTML5, Modern CSS3 (Glassmorphism, CSS Custom Properties, Responsive Grid/Flexbox), Vanilla ES6 JavaScript Modules |
| **Backend / DB** | Supabase, PostgreSQL 15, PostgreSQL Row Level Security (RLS), PL/pgSQL Triggers |
| **Authentication** | Supabase Auth (JWT email/password) + Demo User Switcher |
| **Storage** | Supabase Storage (`lost-found-images` bucket) + Fallback Base64 Data URL |
| **Icons & UI** | Lucide Icons, Unsplash Curated Media |
| **Deployment** | Vercel (`vercel.json`), Netlify (`netlify.toml`), or any static web server |

---

## 🗄️ Database Schema & Entities

The complete database schema DDL is located in [`supabase/schema.sql`](./supabase/schema.sql):

### 1. `profiles`
*Linked with `auth.users` on cascade delete*
- `id` (uuid, primary key)
- `full_name` (text)
- `email` (text)
- `phone` (text)
- `avatar_url` (text)
- `created_at` (timestamptz)

### 2. `items`
*Lost and found posts*
- `id` (uuid, primary key)
- `user_id` (uuid, references `profiles.id`)
- `type` (`lost` | `found`)
- `title` (text)
- `description` (text)
- `category` (`Electronics`, `Wallets & Bags`, `Keys`, `IDs & Cards`, `Clothing`, `Pets`, etc.)
- `location` (text)
- `item_date` (date)
- `image_url` (text)
- `contact_info` (text)
- `status` (`open` | `pending_claim` | `resolved`)
- `created_at` (timestamptz)

### 3. `claims`
*Proof submissions and resolution*
- `id` (uuid, primary key)
- `item_id` (uuid, references `items.id`)
- `claimant_id` (uuid, references `profiles.id`)
- `message` (text - proof of ownership details)
- `status` (`pending` | `approved` | `rejected`)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### 4. `notifications`
*User alerts and status updates*
- `id` (uuid, primary key)
- `user_id` (uuid, references `profiles.id`)
- `message` (text)
- `link_url` (text)
- `read_at` (timestamptz)
- `created_at` (timestamptz)

---

## 🧠 Smart Similarity Matching Logic

When scanning items, the algorithm computes a weighted score $S \in [0, 100]\%$:

$$S = 0.35 \cdot S_{\text{category}} + 0.35 \cdot S_{\text{text}} + 0.15 \cdot S_{\text{location}} + 0.15 \cdot S_{\text{date}}$$

- **Category Score ($S_{\text{category}}$)**: $1.0$ for exact match, $0.4$ for related categories (e.g., Wallets & Bags with IDs & Cards).
- **Text Score ($S_{\text{text}}$)**: Jaccard coefficient on normalized tokens (stop-word filtered) combined with Levenshtein fuzzy distance on title keywords.
- **Location Score ($S_{\text{location}}$)**: Keyword & n-gram overlap between lost and found locations.
- **Date Score ($S_{\text{date}}$)**: Temporal proximity decay (maximum score for reports within 24–72 hours).

---

## ⚡ Quick Start & Running Locally

Because this project uses native modern ES6 modules and standard web APIs, no heavy build pipeline (`npm install`) is required!

### Option 1: Using Python's Built-in Server
Open PowerShell / Terminal in this directory and run:
```powershell
python -m http.server 3000
```
Then visit [http://localhost:3000](http://localhost:3000) in your browser.

### Option 2: Using Node `npx serve`
```powershell
npx serve .
```

### Option 3: VS Code Live Server
Right-click `index.html` in VS Code and select **"Open with Live Server"**.

---

## ☁️ Connecting Live Supabase Backend

1. Create a free project at [supabase.com](https://supabase.com).
2. Open the **SQL Editor** in your Supabase dashboard and run the entire script in [`supabase/schema.sql`](./supabase/schema.sql).
3. In the portal header, click the **Settings (gear icon)**.
4. Paste your **Supabase Project URL** and **Anon Key**, uncheck "Force Standalone Demo Mode", and click **Save Settings**.
5. The portal will automatically connect to your live PostgreSQL database and Supabase Auth.

---

## 🧪 Demonstration Scenarios

1. **Explore Existing Demo Items**:
   - Notice the "Space Gray MacBook Air M2" (Lost by Bob Martinez) and "Apple MacBook Air with Astronaut Sticker" (Found by Alice Chen).
   - Click the **Smart Matches** tab to view the algorithm's side-by-side comparison ($90\%$ match).
2. **Submit a Claim**:
   - Switch active demo user to **Bob Martinez** via the top-right profile selector.
   - Click **Claim** on Alice's found MacBook or click **Claim This Found Match** in the Smart Matches tab.
   - Submit your proof of ownership.
3. **Approve Claim as Finder**:
   - Switch active user back to **Alice Chen**.
   - Notice the notification badge counter updates instantly!
   - Click the notification or go to the **Claims Portal** tab.
   - Review Bob's proof and click **Approve & Release**.
   - Notice the MacBook Air status updates to **Resolved** across the portal.
4. **Report a New Item**:
   - Click **Report Item**, select "I Lost an Item" or "I Found an Item", fill in details, drag-and-drop a photo, and watch it immediately appear on the board with automatic similarity calculations.
